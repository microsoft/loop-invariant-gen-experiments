// Source: data/benchmarks/LinearArbitrary-SeaHorn/pie/ICE/benchmarks/incn.c
#include <stdlib.h>
#define assume(e) if(!(e)) exit(-1);
extern int unknown_int(void);

void main()
{
  int x, N;
  x = 0;
  N = unknown_int();
  if (N < 0)
    
return;

  while(x < N)
  {
    x = x + 1;
  }
  {;
//@ assert(x == N);
}
    
return;

}
