// Source: data/benchmarks/LinearArbitrary-SeaHorn/pie/ICE/benchmarks/w1.c
#include <stdlib.h>
#define assume(e) if(!(e)) exit(-1);
extern int unknown_int(void);

void main() {
	int n = unknown_int();
	if(n < 0)
	  
return;

	int x = 0;

 	while (x < n) {

		x = x + 1;

	}
	{;
//@ assert(x == n);
}

}