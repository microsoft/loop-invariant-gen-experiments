// Source: data/benchmarks/LinearArbitrary-SeaHorn/pie/ICE/benchmarks/incn.v.c
#include <stdlib.h>
#define assume(e) if(!(e)) exit(-1);
extern int unknown_int(void);

int main()
{
  int x, N, v1,v2,v3;
  x = 0;
  N = unknown_int();
  while(x < N)
  {
    x = x + 1;
    v1 = unknown_int();
    v2 = unknown_int();
    v3 = unknown_int();
  }
  {;
//@ assert(N < 0 || x == N);
}
    
}
