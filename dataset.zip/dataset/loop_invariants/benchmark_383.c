// Source: data/benchmarks/sv-benchmarks/loop-new/count_by_k.c
#include <stdlib.h>
#define assume(e) if(!(e)) exit(-1);
#define LARGE_INT 1000000
extern int unknown_int(void);

int main() {
    int i;
    int k;
    k = unknown_int();
    if (!(0 <= k && k <= 10)) return 0;
    for (i = 0; i < LARGE_INT*k; i += k) ;
    {;
//@ assert(i == LARGE_INT*k);
}

    return 0;
}