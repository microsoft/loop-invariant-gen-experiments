// Source: data/benchmarks/code2inv/101.c
#include <stdlib.h>
#define assume(e) if(!(e)) exit(-1);

int main() {
  
  int n;
  int x;
  
  (x = 0);
  
  while ((x < n)) {
    {
    (x  = (x + 1));
    }

  }
  
if ( (x != n) )
{;
//@ assert( (n < 0) );
}

}