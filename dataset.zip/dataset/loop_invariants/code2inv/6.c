// Source: data/benchmarks/code2inv/6.c
#include <stdlib.h>
#define assume(e) if(!(e)) exit(-1);

int main()
{
    int v1,v2,v3;
    int x = 0;
    int size;
    int y, z;

    while(x < size) {
       x += 1;
       if( z <= y) {
          y = z;
       }
    }

    if(size > 0) {
       {;
//@ assert(z >= y);
}

    }
}