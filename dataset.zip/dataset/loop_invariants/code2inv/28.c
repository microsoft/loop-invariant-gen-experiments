// Source: data/benchmarks/code2inv/28.c
#include <stdlib.h>
#define assume(e) if(!(e)) exit(-1);

int main() {
  
  int n;
  int x;
  
  (x = n);
  
  while ((x > 0)) {
    {
    (x  = (x - 1));
    }

  }
  
if ( (x != 0) )
{;
//@ assert( (n < 0) );
}

}