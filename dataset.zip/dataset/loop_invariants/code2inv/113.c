// Source: data/benchmarks/code2inv/113.c
#include <stdlib.h>
#define assume(e) if(!(e)) exit(-1);

int main() {
  
  int i;
  int n;
  int sn;
  int v1;
  int v2;
  int v3;
  
  (sn = 0);
  (i = 1);
  
  while ((i <= n)) {
    {
    (i  = (i + 1));
    (sn  = (sn + 1));
    }

  }
  
if ( (sn != 0) )
{;
//@ assert( (sn == n) );
}

}