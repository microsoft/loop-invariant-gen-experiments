// Source: data/benchmarks/code2inv/105.c
#include <stdlib.h>
#define assume(e) if(!(e)) exit(-1);

int main() {
  
  int n;
  int v1;
  int v2;
  int v3;
  int x;
  
  (x = 0);
  
  while ((x < n)) {
    {
    (x  = (x + 1));
    }

  }
  
if ( (n >= 0) )
{;
//@ assert( (x == n) );
}

}