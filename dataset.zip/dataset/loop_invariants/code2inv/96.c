// Source: data/benchmarks/code2inv/96.c
#include <stdlib.h>
#define assume(e) if(!(e)) exit(-1);

int main() {
  
  int i;
  int j;
  int x;
  int y;
  
  (j = 0);
  (i = 0);
  (y = 1);
  
  while ((i <= x)) {
    {
    (i  = (i + 1));
    (j  = (j + y));
    }

  }
  
if ( (i != j) )
{;
//@ assert( (y != 1) );
}

}