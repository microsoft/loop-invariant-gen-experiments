// Source: data/benchmarks/code2inv/129.c
#include <stdlib.h>
#define assume(e) if(!(e)) exit(-1);

int main() {
  
  int x;
  int y;
  int z1;
  int z2;
  int z3;
  
  (x = 1);
  
  while ((x < y)) {
    {
    (x  = (x + x));
    }

  }
  
{;
//@ assert( (x >= 1) );
}

}