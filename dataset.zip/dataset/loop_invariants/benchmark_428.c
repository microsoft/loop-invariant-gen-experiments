// Source: data/benchmarks/sv-benchmarks/loop-zilu/benchmark43_conjunctive.c
#include <stdlib.h>
#define assume(e) if(!(e)) exit(-1);
extern int unknown_int(void);

#include <assert.h>

int main() {
  int x = unknown_int();
  int y = unknown_int();
  if (!(x < 100 && y < 100)) return 0;
  while (x < 100 && y < 100) {
    x=x+1;
    y=y+1;
  }
  {;
//@ assert(x == 100 || y == 100);
}

  return 0;
}