// Source: data/benchmarks/LinearArbitrary-SeaHorn/pie/ICE/benchmarks/fig9.v.c
#include <stdlib.h>
#define assume(e) if(!(e)) exit(-1);
extern int unknown_int(void);

int main() {

	int x, y, v1,v2,v3;
	x = 0;
	y = 0;

	while(y >= 0) {

		y = y + x;
		v1 = unknown_int();
		v2 = unknown_int();
		v3 = unknown_int();
	
	}

	{;
//@ assert(0 == 1);
}

}