// Source: data/benchmarks/LinearArbitrary-SeaHorn/pie/ICE/benchmarks/fig1.v.c
#include <stdlib.h>
#define assume(e) if(!(e)) exit(-1);
extern int unknown_int(void);

int main() {

	int x = -50;
	int y, v1,v2,v3;

 	while (x < 0) {
		x = x + y;
		y++;
		v1 = unknown_int();
		v2 = unknown_int();
		v3 = unknown_int();
	
	}
	{;
//@ assert(y > 0);
}

}