// Source: data/benchmarks/LinearArbitrary-SeaHorn/pie/ICE/benchmarks/decn.c
#include <stdlib.h>
#define assume(e) if(!(e)) exit(-1);
extern int unknown_int(void);

void main()
{
  int x, m, N;
  N = unknown_int();
  if (N < 0)
    
return;

  x = N;
  while(x > 0)
  {
    x = x - 1;
  }
  {;
//@ assert(x == 0);
}
    
}
