// Source: data/benchmarks/LinearArbitrary-SeaHorn/pie/ICE/benchmarks/fig1.c
#include <stdlib.h>
#define assume(e) if(!(e)) exit(-1);

int main() {

	int x = -50;
	int y;

 	while (x < 0) {
		x = x + y;
		y++;
	
	}
	{;
//@ assert(y > 0);
}

}