// Source: data/benchmarks/LinearArbitrary-SeaHorn/pie/ICE/benchmarks/w2.c
#include <stdlib.h>
#define assume(e) if(!(e)) exit(-1);
extern int unknown_int(void);

void main() {

	int n = unknown_int();
	if (n <= 0)
		
return;

	int x = 0;
	int input = unknown_int();

 	while ( 0 == 0 ) {
		if ( input ) {

			x = x + 1;
			if (x >= n ) {
				break;
			}
		}
		input = unknown_int();
	}
	{;
//@ assert(x == n);
}

}