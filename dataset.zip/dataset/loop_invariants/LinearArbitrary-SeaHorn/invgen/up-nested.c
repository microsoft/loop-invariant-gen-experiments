// Source: data/benchmarks/LinearArbitrary-SeaHorn/invgen/up-nested.c
#include <stdlib.h>
#define assume(e) if(!(e)) exit(-1);
extern int unknown(void);

extern int unknown();

void main() {
  int n,j,i,k;

  i = 0;
  k = 0;
  j = unknown();
  n = unknown();

  if ( j<=n ) {
  while ( j <= n ) {
    
    j++;
  }
  {;
//@ assert( i>= 0);
}

  }
}